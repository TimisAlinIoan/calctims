const express = require('express');
const path = require('path');
const app = express();
const fs = require('fs');

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

file=fs.readFileSync("file.json","utf8")
lista=JSON.parse(file);
file1=fs.readFileSync("idcontatore.json","utf8")
id=JSON.parse(file1);

app.get('/', function(req, res){
    
    html="<html><head> <link rel=\"stylesheet\" href=\"style.css\"></head><body><div style=\"display: block; font-size: 20px; width: 100%; text-align:center; align-items:center\">LISTA DI COSE DA FARE";
    if(lista.dafare!=undefined)
    lista.dafare.forEach(e => {
        bottonescambio="<form action=\"/\" method=\"post\"><input type=\"text\" value=\""+e.id+"\" name=\"fatto\" style=\"display: none;\"><button type=\"submit\">fatto</button></form>"
        html+="<div style=\"border-style: double;\"><p>"+e.titolo+"</p><div class=\"interno\">"+bottonescambio+"<h5>"+e.testo+"</h5>"
        
        elimina="<form action=\"/\" method=\"post\"><input type=\"text\" value=\""+e.id+"\" name=\"delete\" style=\"display: none;\"><button type=\"submit\">elimina</button></form></div></div>";
        html+=elimina;
    });
    html+="</div><div style=\"display: block; font-size: 20px; width: 100%; text-align:center; align-items:center\">LISTA DI COSE GIA FATTE"
    if(lista.fatti!=undefined)
    lista.fatti.forEach(e => {
        bottonescambio="<form action=\"/\" method=\"post\"><input type=\"text\" value=\""+e.id+"\" name=\"dafare\" style=\"display: none;\"><button type=\"submit\">da fare</button></form>"
        html+="<div style=\"border-style: double;\"><p>"+e.titolo+"</p><div class=\"interno\">"+bottonescambio+"<h5>"+e.testo+"</h5>"
        
        elimina="<form action=\"/\" method=\"post\"><input type=\"text\" value=\""+e.id+"\" name=\"delete\" style=\"display: none;\"><button type=\"submit\">elimina</button></form></div></div>";
        html+=elimina;
    });
    aggiungi="<form action=\"/aggiungi\" method=\"get\"><button type=\"submit\">aggiungi</button></form>"
    html+=aggiungi;
    html+="</div></body></html>"
    res.send(html)

})
app.post('/', function(req, res){
    if(req.body.delete==undefined){
        
        if(req.body.fatto!=undefined){
            elid=req.body.fatto;
            oggetto=lista.dafare.filter(e => e.id==elid)
            lista.dafare=lista.dafare.filter(e => e.id!=elid)
            lista.fatti.push(oggetto[0])

        }
        if(req.body.dafare!=undefined){
            elid=req.body.dafare;
            
            oggetto=lista.fatti.filter(e => e.id==elid)
            lista.fatti=lista.fatti.filter(e => e.id!=elid)
            lista.dafare.push(oggetto[0])

        }
        file=JSON.stringify(lista);
        fs.writeFileSync("file.json",file,"utf8")
    }
    else{
        elid=req.body.delete;
        if(lista.dafare!=undefined)
        lista.dafare=lista.dafare.filter(e => e.id!=elid)
        if(lista.fatti!=undefined)
        lista.fatti=lista.fatti.filter(e => e.id!=elid)
        file=JSON.stringify(lista);
        fs.writeFileSync("file.json",file,"utf8")
        
    }
    res.redirect("/")

    
})
app.get("/aggiungi",function(req, res){
    html="<html><head> <link rel=\"stylesheet\" href=\"style.css\"></head><body><div style=\"display: block; font-size: 20px; width: 100%; text-align:center; align-items:center\">AGGIUNGI";
    html+="<form action=\"/aggiungi\" method=\"post\">TITOLO<input type=\"text\" name=\"titolo\" required><br>TESTO <textarea name=\"testo\"></textarea><br><button type=\"submit\" required>aggiungi</button></form>"
    html+="</div></body></html>"
    res.send(html)
})
app.post("/aggiungi",function(req, res){
    oggetto={}
    oggetto.id=id.id+1;
    id.id++;
    oggetto.titolo=req.body.titolo;
    oggetto.testo=req.body.testo;
    lista.dafare.push(oggetto)
    file=JSON.stringify(lista);
    fs.writeFileSync("file.json",file,"utf8")
    file1=JSON.stringify(id)
    fs.writeFileSync("idcontatore.json",file1,"utf8")
    res.redirect("/")
})

app.listen(3000, () => {
    console.log('http://localhost:3000');
});
