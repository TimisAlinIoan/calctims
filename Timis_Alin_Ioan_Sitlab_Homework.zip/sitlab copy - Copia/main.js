const http = require('http');
const fs = require('fs');
const path = require('path');
const express = require('express');
const app=express();
var volte1=1;
var volte2=1;
var login=1;
app.use(express.urlencoded({ extended: true }));

app.use(express.static('www'));

let utenti ={} 
fs.readFile(__dirname + '/json/utenti.json', 'utf-8', (err, data) => {
    if (err) {
        console.error("Error reading utenti.json:", err);
        return;
    }
    utenti = JSON.parse(data);
});

let sensori = [];
fs.readFile(__dirname + '/json/sensori.json', 'utf-8', (err, data) => {
    if (err) {
        console.error("Error reading sensori.json:", err);
        return;
    }
    sensori = JSON.parse(data);
});
app.get('/www/index.css', function(req,res){
    res.sendFile(__dirname+'/www/index.css');
});
app.get('/', function(req,res){
    req.body.utente=" ";
    req.body.passwd=" ";
    login=1;
    res.redirect("http://127.0.0.1:8080/?accesso=0");
    
});
app.post('/', function(req,res){
    
    let utente=req.body.utente;
    let passwd=req.body.passwd;
    login=1;
    if (utente==utenti.utente && passwd==utenti.passwd){
        res.redirect("http://127.0.0.1:8080/sensori");
        login=0;
    }
    else
        res.redirect(`http://127.0.0.1:8080/?accesso=1`);
    
});


app.get('/sensori', function(req,res){
    if (login==1)
        res.redirect('/');
    res.sendFile(__dirname + '/www/sensori.html');
    volte1=1;
    volte2=1;
});

app.get('/sensori/cerca', function(req,res){
    if (login==1)
        res.redirect('/');
    res.sendFile(__dirname +"/www/cerca.html");
    
    
});
app.post('/sensori/cerca', function(req,res){
    let id=parseInt(req.body.id,10);
    const sensore= sensori.find(u=>u.id===id);
    if (!sensore)
        res.send(`<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>ESITO</title>
    <link rel="stylesheet" href="/www/index.css">
</head>
<body>
    <h1>Il sensore non e' stato trovato</h1>
    <button id="torna"> torna</button>
    <script>
        document.getElementById("torna").onclick = function() {
            window.location.href = "/sensori"; 
        };
    </script>
    
</body>
</html>`);
else{
    let matricola=sensore["matricola"];
    let zona=sensore["zona"];
    let lettura=sensore["lettura"];
    
    const url=`http://127.0.0.1:8080/sensori/cerca/modifica?id=${id}&matricola=${matricola}&zona=${zona}&lettura=${lettura}&type=mod`;
    res.redirect(url);
}
});
app.get('/sensori/cerca/modifica', function(req,res){
    if (login==1)
        res.redirect('/');
    res.sendFile(__dirname +"/www/modifica.html");


});

app.post('/sensori/cerca/modifica', function(req,res){
    
    
    let id=parseInt(req.body.id,10);
    let matricola=req.body.matricola;
    let zona=req.body.zona;
    let lettura=parseFloat(req.body.lettura);
    const sensore = sensori.find(u => u.id === id);
    sensore.matricola = matricola;
    sensore.zona = zona;
    sensore.lettura = lettura;
    volte1=1;
        

    fs.writeFile(__dirname + '/json/sensori.json', JSON.stringify(sensori, null, 2), 'utf-8', (err) => {
        if (err) {
            return res.status(500).send("Error saving data.");
        }
        res.status(200).send(`<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>ESITO</title>
    <link rel="stylesheet" href="/www/index.css">
</head>
<body>
    <h1>Il sensore e' stato modificato con successo</h1>
    <button id="torna"> torna</button>
    <script>
        document.getElementById("torna").onclick = function() {
            window.location.href = "/sensori"; 
        };
    </script>
    
</body>
</html>
`)
    });
});

app.get('/sensori/cerca1', function(req,res){
    if (login==1)
        res.redirect('/');
    res.sendFile(__dirname +"/www/cerca1.html");
    
    
});
app.post('/sensori/cerca1', function(req,res){
    let id=parseInt(req.body.id,10);

    const sensore= sensori.find(u=>u.id===id);
    if (!sensore)
        res.send(`<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>ESITO</title>
    <link rel="stylesheet" href="/www/index.css">
</head>
<body>
    <h1>Il sensore non e' stato trovato</h1>
    <button id="torna"> torna</button>
    <script>
        document.getElementById("torna").onclick = function() {
            window.location.href = "/sensori"; 
        };
    </script>
    
</body>
</html>`);
    let matricola=sensore["matricola"];
    let zona=sensore["zona"];
    let lettura=sensore["lettura"];
    
    const url=`http://127.0.0.1:8080/sensori/cerca/modifica?id=${id}&matricola=${matricola}&zona=${zona}&lettura=${lettura}&type=let`;
    res.redirect(url);
});
app.get('/sensori/cerca/lettura', function(req,res){
    if (login==1)
        res.redirect('/');
    res.sendFile(__dirname +"/www/lettura.html");


});



app.get('/sensori/create', function(req,res){
    if (login==1)
        res.redirect('/');
    var maggiore=0;
    for (let element in sensori){
        if (sensori[element].id>maggiore)
                maggiore=sensori[element].id;
    }
    if (volte1==1){
        res.redirect(`/sensori/create?id=${maggiore+1}`);
        volte1=2;
    }
    res.sendFile(__dirname +"/www/create.html");
    
});
app.post('/sensori/create', function(req,res){
    volte1=1;
    let create ={
        "id": 0,
        "matricola":"",
        "zona":"",
        "lettura":0.0,
    }
    let id=parseInt(req.body.id,10);
    let matricola=req.body.matricola;
    let zona=req.body.zona;
    let lettura=parseFloat(req.body.lettura);
    create.id=id;
    create.matricola = matricola;
    create.zona = zona;
    create.lettura = lettura;
    sensori.push(create);


    fs.writeFile(__dirname + '/json/sensori.json', JSON.stringify(sensori, null, 2), 'utf-8', (err) => {
        if (err) {
            return res.status(500).send("Error saving data.");
        }
        res.status(200).send(`<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>ESITO</title>
    <link rel="stylesheet" href="/www/index.css">
</head>
<body>
    <h1>Il sensore e' stato aggiunto con successo</h1>
    <button id="torna"> torna</button>
    <script>
        document.getElementById("torna").onclick = function() {
            window.location.href = "/sensori"; 
        };
    </script>
    
</body>
</html>
`)
    });
});

app.get('/sensori/elimina', function(req,res){
    if (login==1)
        res.redirect('/');
    res.sendFile(__dirname +"/www/elimina.html");
    
    
});
app.post('/sensori/elimina', function(req,res){
    let id=parseInt(req.body.id,10);
    const sensore= sensori.findIndex(u=>u.id===id);
    if (!sensore)
        res.send(`<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>ESITO</title>
    <link rel="stylesheet" href="/www/index.css">
</head>
<body>
    <h1>Il sensore non e' stato trovato</h1>
    <button id="torna"> torna</button>
    <script>
        document.getElementById("torna").onclick = function() {
            window.location.href = "/sensori"; 
        };
    </script>
    
</body>
</html>`);

        sensori.splice(sensore,1);

    fs.writeFile(__dirname + '/json/sensori.json', JSON.stringify(sensori, null, 2), 'utf-8', (err) => {
        if (err) {
            return res.status(500).send("Error saving data.");
        }
        res.status(200).send(`<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>ESITO</title>
    <link rel="stylesheet" href="/www/index.css">
</head>
<body>
    <h1>Il sensore e' stato eliminato con successo</h1>
    <button id="torna"> torna</button>
    <script>
        document.getElementById("torna").onclick = function() {
            window.location.href = "/sensori"; 
        };
    </script>
    
</body>
</html>
`)
    
        });  
});


const server = http.createServer(app);
server.listen(8080, "127.0.0.1", function() {
console.log("Server attivo su http://127.0.0.1:8080")
})