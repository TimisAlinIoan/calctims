<html>
    <head>
         <link rel="stylesheet" href="style.css">
    </head>
    <body>
      <div style="display: block; font-size: 20px; width: 100%; text-align:center; align-items:center">AGGIUNGI
<?php
session_start();
if(!isset($_SESSION["nome"]))
        header("Location: index.php");
$nomedb="prova";
    $password="";
    $db= new mysqli("localhost","root",$password,$nomedb);
    $utente=$_SESSION["nome"];
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $destinazione="foto/".basename($_FILES["immagine"]["name"]);
      move_uploaded_file($_FILES["immagine"]["tmp_name"], $destinazione);
      $descrizione=$_POST["desc"];
      $db->query("INSERT INTO gallery (nome, files,descr)
      
VALUES ('$utente', '$destinazione','$descrizione')");
  header("Location: main.php");
    }
        ?>
<form action="aggiungi.php" method="post" enctype="multipart/form-data">
  <label>scegli una immagine</label>
  <input type="file" name="immagine" accept="image/*" required><br><br>
  <textarea  name="desc"> descrizione <br><br>
  <input type="submit" value="Upload">
  </div>
</form>
</body>
</html>
