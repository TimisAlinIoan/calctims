<html>
    <head>
         <link rel="stylesheet" href="style.css">
    </head>
    <body >
        <div style="display: block; font-size: 20px; width: 100%; text-align:center; align-items:center">LOGIN
        <form action="main.php" method="post">
        <input type="text" value="logout" name="logout" style="display: none;">
        <button type="submit">logout</button>
        </form>
<?php
session_start();
$nomedb="prova";
    $password="";
    $db= new mysqli("localhost","root",$password,$nomedb);
    $utente=$_SESSION["nome"];
    if(!isset($_SESSION["nome"]))
        header("Location: index.php");
    if (isset($_POST["logout"])){
        session_destroy();
        header("Location: index.php");
    }
    if(isset($_POST["delete"])){
        $id=$_POST["delete"];
       $db->query("DELETE FROM gallery WHERE id = $id");
    }
    $immagini=$db->query("SELECT id,files , descr FROM gallery WHERE nome=\"$utente\"");
    if($immagini->num_rows==0)
        echo "nessuna immagine trovata premi \"aggiungi\" per aggiungere immagini alla gallery";
    else{
         echo "<div class=\"gallery\">";
        
            while ($image = $immagini->fetch_assoc()) {
                 $id=$image["id"];
            echo "<div class=\"img\"><img src=\"".$image["files"]."\" >".$image["descr"]."<form action=\"main.php\" method=\"post\">
        <input type=\"text\" value=\"$id\" name=\"delete\" style=\"display: none;\">
        <button type=\"submit\">elimina</button>
        </form></div>";
        }
        echo "</div>";
            
    }
?>

<form action="aggiungi.php">
  <button type="submit">aggiungi</button>
</form>
</div>
</body>
</html>
