<html>
    <head>
         <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div style="display: block; font-size: 20px; width: 100%; text-align:center; align-items:center">LOGIN
        

<?php
    session_start();
    $nomedb="prova";
    $password="";
    $db= new mysqli("localhost","root",$password,$nomedb);
    /*$db->query("CREATE TABLE login (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(30) NOT NULL,
pass VARCHAR(30) NOT NULL,

)");*/
/*$db->query("CREATE TABLE gallery (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(30) NOT NULL,
files VARCHAR(255) NOT NULL,
descr text
)");*/



    if(isset($_SESSION["nome"]))
         header("Location: main.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $utente=$_POST["nome"];
        $password=$db->query("SELECT pass FROM login where nome=\"$utente\"");
        if($password->num_rows !=0){
            $valore=$password->fetch_assoc();
            if($_POST["password"]==$valore["pass"]){
                $_SESSION["nome"]=$utente;
                header("Location: main.php");

            }
            else
            echo "<form action=\"index.php\" method=\"POST\">
        nome: <input type=\"text\" name=\"nome\" required><br>
        password: <input type=\"text\" name=\"password\" required><br>
        <input type=\"submit\">
        </form>
        <a href=\"registra.php\">Registrati</a>
        <p>password errata</p>"
        ;
        }
        else
            echo "<form action=\"index.php\" method=\"POST\">
        nome: <input type=\"text\" name=\"nome\" required><br>
        password: <input type=\"text\" name=\"password\" required><br>
        <input type=\"submit\">
        </form>
        <a href=\"registra.php\">Registrati</a>
        <p>nome non esistente</p>"
        ;
            
    }
    else
        echo "<form action=\"index.php\" method=\"POST\">
        nome: <input type=\"text\" name=\"nome\" required><br>
        password: <input type=\"text\" name=\"password\" required><br>
        <input type=\"submit\">
        </form>
        <a href=\"registra.php\">Registrati</a>"
        ;


?>
</div>
    </body>
</html>


