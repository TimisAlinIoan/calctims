<html>
    <head>
         <link rel="stylesheet" href="style.css">
    </head>
    <body>
     <div style="display: block; font-size: 20px; width: 100%; text-align:center; align-items:center">LOGIN



<?php
$nomedb="prova";
    $password="";
    $db= new mysqli("localhost","root",$password,$nomedb);
    
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $utente=$_POST["nome"];
        $esiste=$db->query("SELECT pass FROM login WHERE nome=\"$utente\"");
        if($esiste->num_rows!=0){
            echo "<form action=\"registra.php\" method=\"POST\">
        nome: <input type=\"text\" name=\"nome\" required><br>
        password: <input type=\"text\" name=\"password\" required><br>
        conferma password: <input type=\"text\" name=\"cpassword\" required><br>
        <input type=\"submit\">
        </form>
        <a href=\"index.php\">login</a>
        <p>nome già esistente</p>";
        exit();
        }
        $password=$_POST["password"];
        $cpassword=$_POST["cpassword"];
        if($password!=$cpassword){
            echo "<form action=\"registra.php\" method=\"POST\">
        nome: <input type=\"text\" name=\"nome\" required><br>
        password: <input type=\"text\" name=\"password\" required><br>
        conferma password: <input type=\"text\" name=\"cpassword\" required><br>
        <input type=\"submit\">
        </form>
        <a href=\"index.php\">login</a>
        <p>password non combaciano</p>";
        exit();
        }
        $db->query("INSERT INTO login (nome, pass)
VALUES ('$utente', '$password')");
header("Location: index.php");
        
    }
    
        echo "<form action=\"registra.php\" method=\"POST\">
        nome: <input type=\"text\" name=\"nome\" required><br>
        password: <input type=\"text\" name=\"password\" required><br>
        conferma password: <input type=\"text\" name=\"cpassword\" required><br>
        <input type=\"submit\">
        </form>
        <a href=\"index.php\">login</a>"
        ;
    ?>
    </div>
    </body>
</html>
