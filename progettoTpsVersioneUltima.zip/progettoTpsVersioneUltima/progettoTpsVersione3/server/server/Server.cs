using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;

namespace ServerDocumenti
{
    public class Messaggio
    {
        public string tipo { get; set; }
        public string utente { get; set; }
        public string password { get; set; }
        public string idDocumento { get; set; }
        public string contenuto { get; set; }
        public string titolo { get; set; }
        public string condivisoCon { get; set; }
        public bool successo { get; set; }
        public string messaggio { get; set; }
        public string autore { get; set; }
        public bool bloccato { get; set; }
        public string utenteBloccante { get; set; }
        public List<InfoDocumento> documenti { get; set; }
    }

    public class InfoDocumento
    {
        public string idDocumento { get; set; }
        public string titolo { get; set; }
        public string proprietario { get; set; }
        public List<string> condivisoCon { get; set; }
    }

    public class Documento
    {
        public string Id { get; set; }
        public string Contenuto { get; set; }
        public bool Bloccato { get; set; }
        public string UtenteBloccante { get; set; }
        public Dictionary<string, Socket> Collaboratori { get; set; } = new Dictionary<string, Socket>();
    }

    public class Server
    {
        private const int PORTA = 8888;
        private const string FILE_UTENTI = "users.csv";
        private const string CARTELLA_DOCS = "docs";
        private const string INDICE_DOCS = "docs/index.csv";
        private static readonly object lockFile = new object();
        private Dictionary<string, Documento> documenti = new Dictionary<string, Documento>();

        public void Avvia()
        {
            if (!Directory.Exists(CARTELLA_DOCS)) Directory.CreateDirectory(CARTELLA_DOCS);
            if (!File.Exists(FILE_UTENTI)) File.WriteAllText(FILE_UTENTI, "utente,password\n");
            if (!File.Exists(INDICE_DOCS)) File.WriteAllText(INDICE_DOCS, "id,proprietario,condiviso,titolo\n");

            Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.Bind(new IPEndPoint(IPAddress.Any, PORTA));
            server.Listen(100);

            Console.WriteLine($"Server avviato sulla porta {PORTA}");

            while (true)
            {
                Socket client = server.Accept();
                new Thread(() => GestisciClient(client)) { IsBackground = true }.Start();
            }
        }

        private void GestisciClient(Socket socket)
        {
            string utente = null;
            try
            {
                while (socket.Connected)
                {
                    Messaggio msg = Ricevi(socket);
                    if (msg == null) break;

                    switch (msg.tipo)
                    {
                        case "LOGIN": utente = Login(socket, msg); break;
                        case "SIGNUP": Registra(socket, msg); break;
                        case "LIST_DOCS": ListaDocumenti(socket, msg); break;
                        case "CREATE_DOC": CreaDocumento(socket, msg); break;
                        case "OPEN_DOC": ApriDocumento(socket, msg); break;
                        case "DELETE_DOC": EliminaDocumento(socket, msg); break;
                        case "SHARE_DOC": CondividiDocumento(socket, msg); break;
                        case "EDIT": Modifica(socket, msg); break;
                        case "LOCK_DOC": Blocca(socket, msg); break;
                        case "UNLOCK_DOC": Sblocca(msg); break;
                        case "CLOSE_DOC": ChiudiDocumento(msg); break;
                    }
                }
            }
            catch { }
            finally
            {
                if (utente != null)
                {
                    foreach (var doc in documenti.Values)
                    {
                        doc.Collaboratori.Remove(utente);
                        if (doc.UtenteBloccante == utente) { 
                            doc.Bloccato = false; 
                            doc.UtenteBloccante = "";
                            NotificaTutti(doc, "DOC_UNLOCKED"); 
                        }
                    }
                    Console.WriteLine($"{utente} si è disconnesso");
                }
                socket?.Close();
            }
        }

        private string Login(Socket socket, Messaggio msg)
        {
            string u = msg.utente?.ToLower().Trim();
            
                foreach (string riga in File.ReadAllLines(FILE_UTENTI).Skip(1))
                {
                    var p = riga.Split(',');
                    if (p.Length >= 2 && p[0] == u && p[1] == msg.password)
                    {
                        Invia(socket, new Messaggio { tipo = "LOGIN_RESPONSE", successo = true });
                        Console.WriteLine($"{u} si è connesso");
                        return u;
                    }
                }
            
            Invia(socket, new Messaggio { tipo = "LOGIN_RESPONSE", successo = false, messaggio = "Credenziali non valide" });
            return null;
        }

        private void Registra(Socket socket, Messaggio msg)
        {
            string u = msg.utente?.ToLower().Trim();
            
                if (File.ReadAllLines(FILE_UTENTI).Skip(1).Any(r => r.Split(',')[0] == u))
                {
                    Invia(socket, new Messaggio { tipo = "SIGNUP_RESPONSE", successo = false, messaggio = "Utente già esistente" });
                    return;
                }
                File.AppendAllText(FILE_UTENTI, $"{u},{msg.password}\n");
            
            Invia(socket, new Messaggio { tipo = "SIGNUP_RESPONSE", successo = true });
            Console.WriteLine($"Nuovo utente: {u}");
        }

        private void ListaDocumenti(Socket socket, Messaggio msg)
        {
            string u = msg.utente?.ToLower();
            var lista = new List<InfoDocumento>();
            
                foreach (string riga in File.ReadAllLines(INDICE_DOCS).Skip(1))
                {
                    var p = riga.Split(',');
                    if (p.Length >= 4 && (p[1] == u || p[2].Split(';').Contains(u)))
                    {
                        lista.Add(new InfoDocumento { idDocumento = p[0], titolo = p[3], proprietario = p[1], condivisoCon = string.IsNullOrEmpty(p[2]) ? new List<string>() : p[2].Split(';').ToList() });
                    }
                }
            
            Invia(socket, new Messaggio { tipo = "LIST_DOCS", documenti = lista });
        }

        private void CreaDocumento(Socket socket, Messaggio msg)
        {
            string id = $"doc-{Guid.NewGuid().ToString("N").Substring(0, 8)}";
            string contenuto = "";
            
                File.WriteAllText(Path.Combine(CARTELLA_DOCS, $"{id}.txt"), contenuto);
                File.AppendAllText(INDICE_DOCS, $"{id},{msg.utente},,{msg.titolo ?? "Senza titolo"}\n");
            
            Invia(socket, new Messaggio { tipo = "CREATE_DOC", successo = true, idDocumento = id, titolo = msg.titolo });
            Console.WriteLine($"Documento creato: {msg.titolo}");
        }

        private void ApriDocumento(Socket socket, Messaggio msg)
        {
            string id = msg.idDocumento;
            string fileTxt = Path.Combine(CARTELLA_DOCS, $"{id}.txt");
                string contenutoDisco = "";
                if (File.Exists(fileTxt))
                {
                    contenutoDisco = File.ReadAllText(fileTxt);
                }
                else
                {
                    Invia(socket, new Messaggio { tipo = "ERROR", messaggio = "Documento non trovato" });
                    return;
                }
                if (!documenti.ContainsKey(id))
                {
                    documenti[id] = new Documento { Id = id, Contenuto = contenutoDisco };
                }
                else
                {
                    // Aggiorna sempre il contenuto in memoria con quello dal disco
                    // per garantire che chi apre dopo veda sempre l'ultima versione salvata
                    documenti[id].Contenuto = contenutoDisco;
                }

                var doc = documenti[id];
                doc.Collaboratori[msg.utente] = socket;
                Invia(socket, new Messaggio { tipo = "DOC_CONTENT", idDocumento = id, contenuto = doc.Contenuto });
                if (doc.Bloccato)
                {
                    Invia(socket, new Messaggio { tipo = "DOC_LOCKED", idDocumento = id, bloccato = true, utenteBloccante = doc.UtenteBloccante });
                }
        }

        private void Modifica(Socket socket, Messaggio msg)
        {
            string id = msg.idDocumento;
            lock (lockFile)
            {
                if (!documenti.ContainsKey(id)) return;
                var doc = documenti[id];

                // Se è bloccato da un altro utente, RIFIUTA la modifica
                if (doc.Bloccato && doc.UtenteBloccante != msg.utente)
                {
                    Invia(socket, new Messaggio { tipo = "DOC_LOCKED", idDocumento = id, bloccato = true, utenteBloccante = doc.UtenteBloccante });
                    Invia(socket, new Messaggio { tipo = "DOC_CONTENT", idDocumento = id, contenuto = doc.Contenuto });
                    return;
                }

                // Solo se non è bloccato o se è bloccato da questo stesso utente, accetta la modifica
                doc.Contenuto = msg.contenuto ?? "";
                File.WriteAllText(Path.Combine(CARTELLA_DOCS, $"{id}.txt"), doc.Contenuto);

                // Notifica tutti gli altri collaboratori del nuovo contenuto
                foreach (var c in doc.Collaboratori.Where(c => c.Key != msg.utente))
                {
                    try 
                    { 
                        Invia(c.Value, new Messaggio { tipo = "DOC_CONTENT", idDocumento = id, contenuto = doc.Contenuto, autore = msg.utente }); 
                    } 
                    catch { }
                }

                Invia(socket, new Messaggio { tipo = "SAVE_ACK", successo = true });
                Console.WriteLine($"Documento modificato da {msg.utente}");
            }
        }

        private void Blocca(Socket socket, Messaggio msg)
        {
            string id = msg.idDocumento;
            lock (lockFile)
            {
                if (!documenti.ContainsKey(id)) return;
                var doc = documenti[id];
                if (doc.Bloccato && doc.UtenteBloccante != msg.utente)
                {
                    Invia(socket, new Messaggio { tipo = "DOC_LOCKED", idDocumento = id, bloccato = true, utenteBloccante = doc.UtenteBloccante });
                    return;
                }
                doc.Bloccato = true;
                doc.UtenteBloccante = msg.utente;
                NotificaTutti(doc, "DOC_LOCKED");
            }
        }

        private void Sblocca(Messaggio msg)
        {
            lock (lockFile)
            {
                if (!documenti.ContainsKey(msg.idDocumento)) return;
                var doc = documenti[msg.idDocumento];
                if (doc.UtenteBloccante != msg.utente) return;
                doc.Bloccato = false;
                doc.UtenteBloccante = "";
                NotificaTutti(doc, "DOC_UNLOCKED");
            }
        }

        private void NotificaTutti(Documento doc, string tipo)
        {
            foreach (var c in doc.Collaboratori)
            {
                try { Invia(c.Value, new Messaggio { tipo = tipo, idDocumento = doc.Id, bloccato = doc.Bloccato, utenteBloccante = doc.UtenteBloccante, contenuto = doc.Contenuto }); } catch { }
            }
        }

        private void ChiudiDocumento(Messaggio msg)
        {
                if (!documenti.ContainsKey(msg.idDocumento)) return;
                var doc = documenti[msg.idDocumento];
                doc.Collaboratori.Remove(msg.utente);
                if (doc.UtenteBloccante == msg.utente) { doc.Bloccato = false; doc.UtenteBloccante = ""; NotificaTutti(doc, "DOC_UNLOCKED"); }
                if (doc.Collaboratori.Count == 0) documenti.Remove(msg.idDocumento);
        }

        private void EliminaDocumento(Socket socket, Messaggio msg)
        {
            string u = msg.utente?.ToLower(), id = msg.idDocumento;
            lock (lockFile)
            {
                var righe = File.ReadAllLines(INDICE_DOCS).ToList();
                int idx = righe.FindIndex(r => r.StartsWith($"{id},") && r.Split(',')[1] == u);
                if (idx < 0) { 
                    Invia(socket, new Messaggio { tipo = "DELETE_DOC", successo = false, messaggio = "Non autorizzato" }); 
                    return; 
                }
                righe.RemoveAt(idx);
                File.WriteAllLines(INDICE_DOCS, righe);
                string file = Path.Combine(CARTELLA_DOCS, $"{id}.txt");
                if (File.Exists(file)) 
                    File.Delete(file);
                documenti.Remove(id);
            }
            Invia(socket, new Messaggio { tipo = "DELETE_DOC", successo = true });
            Console.WriteLine($"Documento eliminato da {msg.utente}");
        }

        private void CondividiDocumento(Socket socket, Messaggio msg)
        {
            string u = msg.utente?.ToLower(), id = msg.idDocumento, target = msg.condivisoCon?.ToLower().Trim();
            lock (lockFile)
            {
                if (!File.ReadAllLines(FILE_UTENTI).Skip(1).Any(r => r.Split(',')[0] == target))
                {
                    Invia(socket, new Messaggio { tipo = "SHARE_RESPONSE", successo = false, messaggio = "Utente non trovato" }); return;
                }
                var righe = File.ReadAllLines(INDICE_DOCS).ToList();
                for (int i = 1; i < righe.Count; i++)
                {
                    var p = righe[i].Split(',');
                    if (p[0] == id && p[1] == u)
                    {
                        var lista = string.IsNullOrEmpty(p[2]) ? new List<string>() : p[2].Split(';').ToList();
                        if (!lista.Contains(target)) lista.Add(target);
                        righe[i] = $"{p[0]},{p[1]},{string.Join(";", lista)},{p[3]}";
                        File.WriteAllLines(INDICE_DOCS, righe);
                        Invia(socket, new Messaggio { tipo = "SHARE_RESPONSE", successo = true, messaggio = $"Condiviso con {target}" });
                        Console.WriteLine($"Documento condiviso con {target}");
                        return;
                    }
                }
            }
            Invia(socket, new Messaggio { tipo = "SHARE_RESPONSE", successo = false, messaggio = "Non autorizzato" });
        }

        private void Invia(Socket socket, Messaggio msg)
        {
            try
            {
                byte[] json = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(msg, new JsonSerializerOptions { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull }));
                socket.Send(BitConverter.GetBytes(json.Length));
                socket.Send(json);
            }
            catch { }
        }

        private Messaggio Ricevi(Socket socket)
        {
            try
            {
                byte[] len = new byte[4];
                int r = 0; while (r < 4) { int n = socket.Receive(len, r, 4 - r, SocketFlags.None); if (n == 0) return null; r += n; }
                int lunghezza = BitConverter.ToInt32(len, 0);
                if (lunghezza <= 0 || lunghezza > 10485760) return null;
                byte[] data = new byte[lunghezza];
                r = 0; while (r < lunghezza) { int n = socket.Receive(data, r, lunghezza - r, SocketFlags.None); if (n == 0) return null; r += n; }
                return JsonSerializer.Deserialize<Messaggio>(Encoding.UTF8.GetString(data), new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            catch { return null; }
        }
    }
}
