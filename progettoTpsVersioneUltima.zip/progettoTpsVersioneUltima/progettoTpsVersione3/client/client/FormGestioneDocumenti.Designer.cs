namespace ClienteDocumenti
{
    partial class FormGestioneDocumenti
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.Label lblStato;
        private System.Windows.Forms.Button btnCrea;
        private System.Windows.Forms.Button btnApri;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnCondividi;
        private System.Windows.Forms.Button btnImporta;
        private System.Windows.Forms.Button btnEsporta;
        private System.Windows.Forms.Button btnAggiorna;
        private System.Windows.Forms.Button btnEsci;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.listView = new System.Windows.Forms.ListView();
            this.lblStato = new System.Windows.Forms.Label();
            this.btnCrea = new System.Windows.Forms.Button();
            this.btnApri = new System.Windows.Forms.Button();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnCondividi = new System.Windows.Forms.Button();
            this.btnImporta = new System.Windows.Forms.Button();
            this.btnEsporta = new System.Windows.Forms.Button();
            this.btnAggiorna = new System.Windows.Forms.Button();
            this.btnEsci = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblStato
            this.lblStato.Text = "Pronto";
            this.lblStato.Location = new System.Drawing.Point(20, 20);
            this.lblStato.AutoSize = true;

            // listView
            this.listView.Location = new System.Drawing.Point(20, 50);
            this.listView.Size = new System.Drawing.Size(800, 330);
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.FullRowSelect = true;
            this.listView.GridLines = true;
            this.listView.Columns.Add("Titolo", 250);
            this.listView.Columns.Add("Proprietario", 150);
            this.listView.Columns.Add("Condiviso Con", 200);
            this.listView.Columns.Add("ID", 100);
            this.listView.DoubleClick += new System.EventHandler(this.ListView_DoubleClick);

            // btnCrea
            this.btnCrea.Text = "Crea";
            this.btnCrea.Location = new System.Drawing.Point(20, 400);
            this.btnCrea.Size = new System.Drawing.Size(90, 35);
            this.btnCrea.BackColor = System.Drawing.Color.FromArgb(0, 120, 215);
            this.btnCrea.ForeColor = System.Drawing.Color.White;
            this.btnCrea.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrea.Click += new System.EventHandler(this.BtnCrea_Click);

            // btnApri
            this.btnApri.Text = "Apri";
            this.btnApri.Location = new System.Drawing.Point(120, 400);
            this.btnApri.Size = new System.Drawing.Size(90, 35);
            this.btnApri.BackColor = System.Drawing.Color.FromArgb(0, 120, 215);
            this.btnApri.ForeColor = System.Drawing.Color.White;
            this.btnApri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApri.Click += new System.EventHandler(this.BtnApri_Click);

            // btnElimina
            this.btnElimina.Text = "Elimina";
            this.btnElimina.Location = new System.Drawing.Point(220, 400);
            this.btnElimina.Size = new System.Drawing.Size(90, 35);
            this.btnElimina.BackColor = System.Drawing.Color.FromArgb(220, 53, 69);
            this.btnElimina.ForeColor = System.Drawing.Color.White;
            this.btnElimina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnElimina.Click += new System.EventHandler(this.BtnElimina_Click);

            // btnCondividi
            this.btnCondividi.Text = "Condividi";
            this.btnCondividi.Location = new System.Drawing.Point(320, 400);
            this.btnCondividi.Size = new System.Drawing.Size(90, 35);
            this.btnCondividi.BackColor = System.Drawing.Color.FromArgb(255, 193, 7);
            this.btnCondividi.ForeColor = System.Drawing.Color.Black;
            this.btnCondividi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCondividi.Click += new System.EventHandler(this.BtnCondividi_Click);

            // btnImporta
            this.btnImporta.Text = "Importa";
            this.btnImporta.Location = new System.Drawing.Point(420, 400);
            this.btnImporta.Size = new System.Drawing.Size(90, 35);
            this.btnImporta.BackColor = System.Drawing.Color.FromArgb(108, 117, 125);
            this.btnImporta.ForeColor = System.Drawing.Color.White;
            this.btnImporta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImporta.Click += new System.EventHandler(this.BtnImporta_Click);

            // btnEsporta
            this.btnEsporta.Text = "Esporta";
            this.btnEsporta.Location = new System.Drawing.Point(520, 400);
            this.btnEsporta.Size = new System.Drawing.Size(90, 35);
            this.btnEsporta.BackColor = System.Drawing.Color.FromArgb(108, 117, 125);
            this.btnEsporta.ForeColor = System.Drawing.Color.White;
            this.btnEsporta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEsporta.Click += new System.EventHandler(this.BtnEsporta_Click);

            // btnAggiorna
            this.btnAggiorna.Text = "Aggiorna";
            this.btnAggiorna.Location = new System.Drawing.Point(620, 400);
            this.btnAggiorna.Size = new System.Drawing.Size(90, 35);
            this.btnAggiorna.BackColor = System.Drawing.Color.FromArgb(40, 167, 69);
            this.btnAggiorna.ForeColor = System.Drawing.Color.White;
            this.btnAggiorna.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAggiorna.Click += new System.EventHandler(this.BtnAggiorna_Click);

            // btnEsci
            this.btnEsci.Text = "Esci";
            this.btnEsci.Location = new System.Drawing.Point(720, 400);
            this.btnEsci.Size = new System.Drawing.Size(90, 35);
            this.btnEsci.BackColor = System.Drawing.Color.Gray;
            this.btnEsci.ForeColor = System.Drawing.Color.White;
            this.btnEsci.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEsci.Click += new System.EventHandler(this.BtnEsci_Click);

            // Form
            this.Text = "Documenti";
            this.ClientSize = new System.Drawing.Size(840, 460);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Controls.Add(this.lblStato);
            this.Controls.Add(this.listView);
            this.Controls.Add(this.btnCrea);
            this.Controls.Add(this.btnApri);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnCondividi);
            this.Controls.Add(this.btnImporta);
            this.Controls.Add(this.btnEsporta);
            this.Controls.Add(this.btnAggiorna);
            this.Controls.Add(this.btnEsci);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}

