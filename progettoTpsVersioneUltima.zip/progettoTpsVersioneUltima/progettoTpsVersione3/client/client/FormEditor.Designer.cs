namespace ClienteDocumenti
{
    partial class FormEditor
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.Label lblStato;
        private System.Windows.Forms.Label lblBlocco;
        private System.Windows.Forms.ComboBox cmbFont;
        private System.Windows.Forms.ComboBox cmbDimensione;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Panel toolbar;
        private System.Windows.Forms.Label lblFont;
        private System.Windows.Forms.Label lblDim;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnI;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnColore;
        private System.Windows.Forms.Button btnChiudi;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.lblStato = new System.Windows.Forms.Label();
            this.lblBlocco = new System.Windows.Forms.Label();
            this.cmbFont = new System.Windows.Forms.ComboBox();
            this.cmbDimensione = new System.Windows.Forms.ComboBox();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.toolbar = new System.Windows.Forms.Panel();
            this.lblFont = new System.Windows.Forms.Label();
            this.lblDim = new System.Windows.Forms.Label();
            this.btnB = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnColore = new System.Windows.Forms.Button();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // Toolbar
            this.toolbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.toolbar.Height = 60;
            this.toolbar.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);

            // lblFont
            this.lblFont.Text = "Font:";
            this.lblFont.Location = new System.Drawing.Point(10, 8);
            this.lblFont.AutoSize = true;
            this.toolbar.Controls.Add(this.lblFont);

            // cmbFont
            this.cmbFont.Location = new System.Drawing.Point(45, 5);
            this.cmbFont.Size = new System.Drawing.Size(100, 25);
            this.cmbFont.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFont.Items.AddRange(new object[] { "Arial", "Calibri", "Times New Roman", "Courier New" });
            this.cmbFont.SelectedIndex = 1;
            this.toolbar.Controls.Add(this.cmbFont);

            // lblDim
            this.lblDim.Text = "Dim:";
            this.lblDim.Location = new System.Drawing.Point(155, 8);
            this.lblDim.AutoSize = true;
            this.toolbar.Controls.Add(this.lblDim);

            // cmbDimensione
            this.cmbDimensione.Location = new System.Drawing.Point(190, 5);
            this.cmbDimensione.Size = new System.Drawing.Size(50, 25);
            this.cmbDimensione.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDimensione.Items.AddRange(new object[] { "10", "12", "14", "16", "18", "20", "24" });
            this.cmbDimensione.SelectedIndex = 1;
            this.toolbar.Controls.Add(this.cmbDimensione);

            // btnB
            this.btnB.Text = "B";
            this.btnB.Location = new System.Drawing.Point(250, 5);
            this.btnB.Size = new System.Drawing.Size(25, 25);
            this.btnB.Font = new System.Drawing.Font("Arial", 9, System.Drawing.FontStyle.Bold);
            this.btnB.Click += new System.EventHandler(this.BtnB_Click);
            this.toolbar.Controls.Add(this.btnB);

            // btnI
            this.btnI.Text = "I";
            this.btnI.Location = new System.Drawing.Point(280, 5);
            this.btnI.Size = new System.Drawing.Size(25, 25);
            this.btnI.Font = new System.Drawing.Font("Arial", 9, System.Drawing.FontStyle.Italic);
            this.btnI.Click += new System.EventHandler(this.BtnI_Click);
            this.toolbar.Controls.Add(this.btnI);

            // btnU
            this.btnU.Text = "U";
            this.btnU.Location = new System.Drawing.Point(310, 5);
            this.btnU.Size = new System.Drawing.Size(25, 25);
            this.btnU.Font = new System.Drawing.Font("Arial", 9, System.Drawing.FontStyle.Underline);
            this.btnU.Click += new System.EventHandler(this.BtnU_Click);
            this.toolbar.Controls.Add(this.btnU);

            // btnColore
            this.btnColore.Text = "A";
            this.btnColore.Location = new System.Drawing.Point(345, 5);
            this.btnColore.Size = new System.Drawing.Size(25, 25);
            this.btnColore.ForeColor = System.Drawing.Color.Red;
            this.btnColore.Click += new System.EventHandler(this.BtnColore_Click);
            this.toolbar.Controls.Add(this.btnColore);

            // btnChiudi
            this.btnChiudi.Text = "Chiudi";
            this.btnChiudi.Location = new System.Drawing.Point(385, 5);
            this.btnChiudi.Size = new System.Drawing.Size(70, 25);
            this.btnChiudi.BackColor = System.Drawing.Color.FromArgb(220, 53, 69);
            this.btnChiudi.ForeColor = System.Drawing.Color.White;
            this.btnChiudi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChiudi.Click += new System.EventHandler(this.BtnChiudi_Click);
            this.toolbar.Controls.Add(this.btnChiudi);

            // lblStato
            this.lblStato.Text = "Connessione...";
            this.lblStato.Location = new System.Drawing.Point(10, 35);
            this.lblStato.AutoSize = true;
            this.toolbar.Controls.Add(this.lblStato);

            // lblBlocco
            this.lblBlocco.Text = "";
            this.lblBlocco.Location = new System.Drawing.Point(200, 35);
            this.lblBlocco.AutoSize = true;
            this.lblBlocco.ForeColor = System.Drawing.Color.Red;
            this.toolbar.Controls.Add(this.lblBlocco);

            // RichTextBox
            this.richTextBox.Location = new System.Drawing.Point(10, 70);
            this.richTextBox.Size = new System.Drawing.Size(860, 480);
            this.richTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.richTextBox.Font = new System.Drawing.Font("Calibri", 12);
            this.richTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            this.richTextBox.TextChanged += new System.EventHandler(this.RichTextBox_TextChanged);

            // Form
            this.Text = "Editor";
            this.ClientSize = new System.Drawing.Size(880, 560);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormEditor_FormClosing);
            this.Controls.Add(this.toolbar);
            this.Controls.Add(this.richTextBox);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}

