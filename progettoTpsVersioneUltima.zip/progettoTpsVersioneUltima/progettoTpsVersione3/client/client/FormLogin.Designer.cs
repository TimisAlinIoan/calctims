namespace ClienteDocumenti
{
    partial class FormLogin
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnRegistrati;
        private System.Windows.Forms.Label lblStato;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnRegistrati = new System.Windows.Forms.Button();
            this.lblStato = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // lblUsername
            var lblUsername = new System.Windows.Forms.Label();
            lblUsername.Text = "Nome utente:";
            lblUsername.Location = new System.Drawing.Point(30, 30);
            lblUsername.AutoSize = true;

            // txtUsername
            this.txtUsername.Location = new System.Drawing.Point(30, 50);
            this.txtUsername.Size = new System.Drawing.Size(270, 25);

            // lblPassword
            var lblPassword = new System.Windows.Forms.Label();
            lblPassword.Text = "Password:";
            lblPassword.Location = new System.Drawing.Point(30, 90);
            lblPassword.AutoSize = true;

            // txtPassword
            this.txtPassword.Location = new System.Drawing.Point(30, 110);
            this.txtPassword.Size = new System.Drawing.Size(270, 25);
            this.txtPassword.PasswordChar = '*';

            // btnLogin
            this.btnLogin.Text = "Accedi";
            this.btnLogin.Location = new System.Drawing.Point(30, 150);
            this.btnLogin.Size = new System.Drawing.Size(130, 35);
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(0, 120, 215);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Click += new System.EventHandler(this.BtnLogin_Click);

            // btnRegistrati
            this.btnRegistrati.Text = "Registrati";
            this.btnRegistrati.Location = new System.Drawing.Point(170, 150);
            this.btnRegistrati.Size = new System.Drawing.Size(130, 35);
            this.btnRegistrati.BackColor = System.Drawing.Color.FromArgb(16, 124, 16);
            this.btnRegistrati.ForeColor = System.Drawing.Color.White;
            this.btnRegistrati.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrati.Click += new System.EventHandler(this.BtnRegistrati_Click);

            // lblStato
            this.lblStato.Text = "";
            this.lblStato.Location = new System.Drawing.Point(30, 195);
            this.lblStato.Size = new System.Drawing.Size(270, 20);
            this.lblStato.ForeColor = System.Drawing.Color.Red;

            // FormLogin
            this.Text = "Editor Documenti - Login";
            this.ClientSize = new System.Drawing.Size(330, 230);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.AcceptButton = this.btnLogin;
            this.Controls.Add(lblUsername);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(lblPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnRegistrati);
            this.Controls.Add(this.lblStato);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}

