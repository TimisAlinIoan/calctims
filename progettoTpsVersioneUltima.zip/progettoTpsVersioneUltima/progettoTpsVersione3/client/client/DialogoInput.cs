using System.Windows.Forms;

namespace ClienteDocumenti
{
    public partial class DialogoInput : Form
    {
        public string Testo { get; private set; }

        public DialogoInput() : this("Anteprima", "Testo:") { }

        public DialogoInput(string titolo, string prompt)
        {
            InitializeComponent();
            this.Text = titolo;
            lblPrompt.Text = prompt;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (DialogResult == DialogResult.OK)
                Testo = txtInput.Text;
            base.OnFormClosing(e);
        }
    }
}

