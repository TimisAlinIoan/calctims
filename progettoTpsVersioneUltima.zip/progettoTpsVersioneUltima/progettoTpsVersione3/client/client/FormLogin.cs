using System;
using System.Drawing;
using System.Net.Sockets;
using System.Windows.Forms;

namespace ClienteDocumenti
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                lblStato.Text = "Inserisci credenziali";
                return;
            }

            try
            {
                Socket socket = SocketHelper.Connetti();
                SocketHelper.Invia(socket, new Messaggio { tipo = "LOGIN", utente = txtUsername.Text.Trim(), password = txtPassword.Text });
                Messaggio risposta = SocketHelper.Ricevi(socket);
                socket.Close();

                if (risposta != null && risposta.successo)
                {
                    this.Hide();
                    new FormGestioneDocumenti(txtUsername.Text.Trim()).ShowDialog();
                    this.Close();
                }
                else
                {
                    lblStato.Text = risposta?.messaggio ?? "Login fallito";
                }
            }
            catch (Exception ex)
            {
                lblStato.Text = $"Errore: {ex.Message}";
            }
        }

        private void BtnRegistrati_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                lblStato.Text = "Inserisci credenziali";
                return;
            }

            try
            {
                Socket socket = SocketHelper.Connetti();
                SocketHelper.Invia(socket, new Messaggio { tipo = "SIGNUP", utente = txtUsername.Text.Trim(), password = txtPassword.Text });
                Messaggio risposta = SocketHelper.Ricevi(socket);
                socket.Close();

                if (risposta != null && risposta.successo)
                {
                    lblStato.ForeColor = Color.Green;
                    lblStato.Text = "Registrazione completata!";
                }
                else
                {
                    lblStato.ForeColor = Color.Red;
                    lblStato.Text = risposta?.messaggio ?? "Registrazione fallita";
                }
            }
            catch (Exception ex)
            {
                lblStato.Text = $"Errore: {ex.Message}";
            }
        }
    }
}

