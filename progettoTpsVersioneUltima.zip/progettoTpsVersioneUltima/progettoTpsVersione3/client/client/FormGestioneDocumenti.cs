using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;

namespace ClienteDocumenti
{
    public partial class FormGestioneDocumenti : Form
    {
        private string utente;
        private bool IsDesignMode => LicenseManager.UsageMode == LicenseUsageMode.Designtime || DesignMode;

        public FormGestioneDocumenti() : this("anteprima") { }

        public FormGestioneDocumenti(string nomeUtente)
        {
            utente = nomeUtente;
            InitializeComponent();
            this.Text = $"Documenti - {utente}";
            if (IsDesignMode) { lblStato.Text = "Design"; return; }
            CaricaDocumenti();
        }

        private void CaricaDocumenti()
        {
            try
            {
                Socket socket = SocketHelper.Connetti();
                SocketHelper.Invia(socket, new Messaggio { tipo = "LIST_DOCS", utente = utente });
                Messaggio risposta = SocketHelper.Ricevi(socket);
                socket.Close();

                listView.Items.Clear();
                if (risposta?.documenti != null)
                {
                    foreach (var doc in risposta.documenti)
                    {
                        var item = new ListViewItem(doc.titolo ?? "Senza titolo");
                        item.SubItems.Add(doc.proprietario);
                        item.SubItems.Add(string.Join(", ", doc.condivisoCon ?? new List<string>()));
                        item.SubItems.Add(doc.idDocumento);
                        listView.Items.Add(item);
                    }
                    lblStato.Text = $"{risposta.documenti.Count} documenti";
                }
            }
            catch (Exception ex) { lblStato.Text = ex.Message; }
        }

        private void BtnCrea_Click(object sender, EventArgs e)
        {
            using (var dialog = new DialogoInput("Crea Documento", "Titolo:"))
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        Socket socket = SocketHelper.Connetti();
                        SocketHelper.Invia(socket, new Messaggio { tipo = "CREATE_DOC", utente = utente, titolo = dialog.Testo ?? "Senza titolo" });
                        SocketHelper.Ricevi(socket);
                        socket.Close();
                        CaricaDocumenti();
                    }
                    catch (Exception ex) { lblStato.Text = ex.Message; }
                }
            }
        }

        private void ApriDocumento()
        {
            if (listView.SelectedItems.Count == 0) return;
            string id = listView.SelectedItems[0].SubItems[3].Text;
            string titolo = listView.SelectedItems[0].SubItems[0].Text;
            var editor = new FormEditor(utente, id, titolo);
            editor.Show();
            CaricaDocumenti();
        }

        private void BtnElimina_Click(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 0) return;
            if (MessageBox.Show("Eliminare il documento?", "Conferma", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    Socket socket = SocketHelper.Connetti();
                    SocketHelper.Invia(socket, new Messaggio { tipo = "DELETE_DOC", utente = utente, idDocumento = listView.SelectedItems[0].SubItems[3].Text });
                    SocketHelper.Ricevi(socket);
                    socket.Close();
                    CaricaDocumenti();
                }
                catch (Exception ex) { lblStato.Text = ex.Message; }
            }
        }

        private void BtnCondividi_Click(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 0) return;
            using (var dialog = new DialogoInput("Condividi", "Nome utente:"))
            {
                if (dialog.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.Testo))
                {
                    try
                    {
                        Socket socket = SocketHelper.Connetti();
                        SocketHelper.Invia(socket, new Messaggio { tipo = "SHARE_DOC", utente = utente, idDocumento = listView.SelectedItems[0].SubItems[3].Text, condivisoCon = dialog.Testo });
                        Messaggio risposta = SocketHelper.Ricevi(socket);
                        socket.Close();
                        lblStato.Text = risposta?.messaggio ?? "Fatto";
                        CaricaDocumenti();
                    }
                    catch (Exception ex) { lblStato.Text = ex.Message; }
                }
            }
        }

        private void BtnAggiorna_Click(object sender, EventArgs e) => CaricaDocumenti();
        private void BtnApri_Click(object sender, EventArgs e) => ApriDocumento();
        private void ListView_DoubleClick(object sender, EventArgs e) => ApriDocumento();
        private void BtnEsci_Click(object sender, EventArgs e) => this.Close();

        private void BtnImporta_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "File di testo (*.txt)|*.txt|File HTML (*.html)|*.html|File RTF (*.rtf)|*.rtf|Tutti i file (*.*)|*.*";
                dialog.Title = "Importa documento";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string contenuto = File.ReadAllText(dialog.FileName);
                        string titolo = Path.GetFileNameWithoutExtension(dialog.FileName);

                        Socket socket = SocketHelper.Connetti();
                        SocketHelper.Invia(socket, new Messaggio { tipo = "CREATE_DOC", utente = utente, titolo = titolo, contenuto = contenuto });
                        SocketHelper.Ricevi(socket);
                        socket.Close();

                        lblStato.Text = $"Importato: {titolo}";
                        CaricaDocumenti();
                    }
                    catch (Exception ex) { lblStato.Text = ex.Message; }
                }
            }
        }

        private void BtnEsporta_Click(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 0) { lblStato.Text = "Seleziona un documento"; return; }

            string id = listView.SelectedItems[0].SubItems[3].Text;
            string titolo = listView.SelectedItems[0].SubItems[0].Text;

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "File di testo (*.txt)|*.txt|File HTML (*.html)|*.html|File RTF (*.rtf)|*.rtf";
                dialog.FileName = titolo;
                dialog.Title = "Esporta documento";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        Socket socket = SocketHelper.Connetti();
                        SocketHelper.Invia(socket, new Messaggio { tipo = "OPEN_DOC", utente = utente, idDocumento = id });
                        Messaggio risposta = SocketHelper.Ricevi(socket);
                        
                        SocketHelper.Invia(socket, new Messaggio { tipo = "CLOSE_DOC", utente = utente, idDocumento = id });
                        socket.Close();

                        if (risposta != null && !string.IsNullOrEmpty(risposta.contenuto))
                        {
                            File.WriteAllText(dialog.FileName, risposta.contenuto);
                            lblStato.Text = $"Esportato: {dialog.FileName}";
                        }
                        else
                        {
                            lblStato.Text = "Documento vuoto";
                        }
                    }
                    catch (Exception ex) { lblStato.Text = ex.Message; }
                }
            }
        }
    }
}

