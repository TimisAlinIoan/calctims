using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ClienteDocumenti
{
    public class Messaggio
    {
        public string tipo { get; set; }
        public string utente { get; set; }
        public string password { get; set; }
        public string idDocumento { get; set; }
        public string contenuto { get; set; }
        public string titolo { get; set; }
        public string condivisoCon { get; set; }
        public bool successo { get; set; }
        public string messaggio { get; set; }
        public string autore { get; set; }
        public bool bloccato { get; set; }
        public string utenteBloccante { get; set; }
        public List<InfoDocumento> documenti { get; set; }
    }

    public class InfoDocumento
    {
        public string idDocumento { get; set; }
        public string titolo { get; set; }
        public string proprietario { get; set; }
        public List<string> condivisoCon { get; set; }
    }

    public static class SocketHelper
    {
        public const string HOST = "localhost";
        public const int PORTA = 8888;

        public static Socket Connetti()
        {
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Connect(HOST, PORTA);
            return socket;
        }

        private static readonly JsonSerializerOptions jsonOptions = new JsonSerializerOptions
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            PropertyNameCaseInsensitive = true
        };

        public static void Invia(Socket socket, Messaggio msg)
        {
            byte[] json = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(msg, jsonOptions));
            socket.Send(BitConverter.GetBytes(json.Length));
            socket.Send(json);
        }

        public static Messaggio Ricevi(Socket socket)
        {
            byte[] len = new byte[4];
            int r = 0;
            while (r < 4)
            {
                int n = socket.Receive(len, r, 4 - r, SocketFlags.None);
                if (n == 0) return null;
                r += n;
            }
            int lunghezza = BitConverter.ToInt32(len, 0);
            if (lunghezza <= 0 || lunghezza > 10485760) return null;

            byte[] data = new byte[lunghezza];
            r = 0;
            while (r < lunghezza)
            {
                int n = socket.Receive(data, r, lunghezza - r, SocketFlags.None);
                if (n == 0) return null;
                r += n;
            }
            return JsonSerializer.Deserialize<Messaggio>(Encoding.UTF8.GetString(data), jsonOptions);
        }
    }
}
