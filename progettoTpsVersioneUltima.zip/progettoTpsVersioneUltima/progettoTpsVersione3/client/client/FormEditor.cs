using System;
using System.ComponentModel;
using System.Drawing;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace ClienteDocumenti
{
    public partial class FormEditor : Form
    {
        private string utente, idDoc;
        private Socket socket;
        private Thread threadRicezione;
        private bool attivo = true;
        private System.Windows.Forms.Timer timerInvio;
        private bool staAggiornando = false;
        private bool modificato = false;
        private bool bloccatoLocale = false;
        private string ultimoContenuto = "";
        private bool IsDesignMode => LicenseManager.UsageMode == LicenseUsageMode.Designtime || DesignMode;

        public FormEditor() : this("anteprima", "anteprima", "Anteprima") { }

        public FormEditor(string nomeUtente, string idDocumento, string titolo)
        {
            InitializeComponent();
            utente = nomeUtente;
            idDoc = idDocumento;
            
            this.Text = $"Editor - {titolo}";
            timerInvio = new System.Windows.Forms.Timer { Interval = 200 };
            timerInvio.Tick += (s, e) => { timerInvio.Stop(); InviaSeModificatoESblocca(); };

            if (IsDesignMode)
            {
                lblStato.Text = "Design";
                return;
            }

            try
            {
                socket = SocketHelper.Connetti();

                threadRicezione = new Thread(RiceviMessaggi) { IsBackground = true };
                threadRicezione.Start();

                Thread.Sleep(100);
                SocketHelper.Invia(socket, new Messaggio { tipo = "OPEN_DOC", utente = utente, idDocumento = idDoc });
            }
            catch (Exception ex) { lblStato.Text = ex.Message; }
        }

        private void RichTextBox_TextChanged(object sender, EventArgs e)
        {
            if (staAggiornando) return;
            
            modificato = true;
            if (!bloccatoLocale)
            {
                SocketHelper.Invia(socket, new Messaggio { tipo = "LOCK_DOC", utente = utente, idDocumento = idDoc });
                bloccatoLocale = true;
            }
            timerInvio.Stop();
            timerInvio.Start();
        }

        private void InviaSeModificatoESblocca()
        {
            if (!modificato || socket == null) return;
            
            string contenutoAttuale = richTextBox.Text;
            if (contenutoAttuale != ultimoContenuto)
            {
                ultimoContenuto = contenutoAttuale;
                SocketHelper.Invia(socket, new Messaggio { tipo = "EDIT", utente = utente, idDocumento = idDoc, contenuto = contenutoAttuale });
                lblStato.Text = "Sincronizzato";
            }
            SocketHelper.Invia(socket, new Messaggio { tipo = "UNLOCK_DOC", utente = utente, idDocumento = idDoc });
            bloccatoLocale = false;
            modificato = false;
        }

        private void RiceviMessaggi()
        {
            while (attivo && socket != null && socket.Connected)
            {
                try
                {
                    Messaggio msg = SocketHelper.Ricevi(socket);
                    if (msg == null) break;
                    this.Invoke((MethodInvoker)delegate { GestisciMessaggio(msg); });
                }
                catch { break; }
            }
        }

        private void GestisciMessaggio(Messaggio msg)
        {
            switch (msg.tipo)
            {
                case "DOC_CONTENT":
                    if (msg.idDocumento == idDoc)
                    {
                        staAggiornando = true;
                        int posizione = richTextBox.SelectionStart;
                        int selezione = richTextBox.SelectionLength;
                        richTextBox.Text = msg.contenuto ?? "";
                        ultimoContenuto = msg.contenuto ?? "";
                        if (posizione <= richTextBox.TextLength)
                            richTextBox.SelectionStart = posizione;
                        else
                            richTextBox.SelectionStart = richTextBox.TextLength;
                        richTextBox.SelectionLength = selezione;
                     
                        staAggiornando = false;
                        if (msg.autore != null && msg.autore != utente)
                            lblStato.Text = $"Aggiornato da {msg.autore}";
                        else
                            lblStato.Text = "Documento caricato";
                    }
                    break;

                case "DOC_UNLOCKED":
                    if (msg.idDocumento == idDoc)
                    {
                        staAggiornando = true;

                        int posizione = richTextBox.SelectionStart;
                        int selezione = richTextBox.SelectionLength;

                        if (!string.IsNullOrEmpty(msg.contenuto))
                        {
                            richTextBox.Text = msg.contenuto;
                            ultimoContenuto = msg.contenuto;
                        }

                        if (posizione <= richTextBox.TextLength)
                            richTextBox.SelectionStart = posizione;
                        else
                            richTextBox.SelectionStart = richTextBox.TextLength;
                        richTextBox.SelectionLength = selezione;
                        
                        staAggiornando = false;
                        
                        richTextBox.ReadOnly = false;
                        lblBlocco.Text = "";
                        lblStato.Text = "Documento sbloccato";
                    }
                    break;

                case "DOC_LOCKED":
                    if (msg.idDocumento == idDoc)
                    {
                        if (msg.utenteBloccante != utente)
                        {
                            richTextBox.ReadOnly = true;
                            lblBlocco.Text = $"Bloccato da {msg.utenteBloccante}";
                            lblBlocco.ForeColor = Color.Red;
                            
                            if (!string.IsNullOrEmpty(msg.contenuto))
                            {
                                staAggiornando = true;
                                int pos = richTextBox.SelectionStart;
                                richTextBox.Text = msg.contenuto;
                                ultimoContenuto = msg.contenuto;
                                if (pos <= richTextBox.TextLength)
                                    richTextBox.SelectionStart = pos;
                                staAggiornando = false;
                            }
                        }
                        else
                        {
                            lblBlocco.Text = "Modificando...";
                            lblBlocco.ForeColor = Color.Green;
                        }
                    }
                    break;

                case "SAVE_ACK":
                    break;

                case "ERROR":
                    lblStato.Text = msg.messaggio;
                    break;
            }
        }

        private void ToggleStile(FontStyle stile)
        {
            Font f = richTextBox.SelectionFont ?? richTextBox.Font;
            richTextBox.SelectionFont = new Font(f.Name, f.Size, f.Style ^ stile);
        }

        private void BtnColore_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
                richTextBox.SelectionColor = colorDialog.Color;
        }

        private void BtnB_Click(object sender, EventArgs e)
        {
            ToggleStile(FontStyle.Bold);
        }

        private void BtnI_Click(object sender, EventArgs e)
        {
            ToggleStile(FontStyle.Italic);
        }

        private void BtnU_Click(object sender, EventArgs e)
        {
            ToggleStile(FontStyle.Underline);
        }

        private void BtnChiudi_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            timerInvio?.Stop();
            attivo = false;
            if (socket != null && socket.Connected)
            {
                try
                {
                    SocketHelper.Invia(socket, new Messaggio { tipo = "EDIT", utente = utente, idDocumento = idDoc, contenuto = richTextBox.Text });
                    SocketHelper.Invia(socket, new Messaggio { tipo = "UNLOCK_DOC", utente = utente, idDocumento = idDoc });
                    SocketHelper.Invia(socket, new Messaggio { tipo = "CLOSE_DOC", utente = utente, idDocumento = idDoc });
                }
                catch { }
            }
            Thread.Sleep(50);
            socket?.Close();
        }
    }
}

