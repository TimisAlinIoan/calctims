﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace progettotps
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            flowLayoutPanel1.Controls.Clear();
            for (int i = 0; i < numericUpDown1.Value; i++)
            {
                colori nuovo = new colori();
                flowLayoutPanel1.Controls.Add(nuovo);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void start_Click(object sender, EventArgs e)
        {
            
            Program.colori.Clear();
            Program.nomi.Clear();
            Program.colori.Add("#FFFFFF");
            Program.nomi.Add("vuoto");
            bool vabene = true;
            foreach (Control a in flowLayoutPanel1.Controls)
            { string colore = ColorTranslator.ToHtml(a.Controls["panel1"].BackColor);
                string nome = a.Controls["textBox1"].Text;
                if (colore == ""||nome=="")
                {
                    vabene = false;
                    break;
                }
                Program.colori.Add(colore);
                Program.nomi.Add(nome);
               
            }
            if (vabene)
            {
                Program.f1 = new Form1(Convert.ToInt32(numericUpDown1.Value), Convert.ToInt32(numericUpDown2.Value));
                Program.f1.ShowDialog();
            }
            else
            {
                lblerror.Text = "Compilare tutti i campi";
                lblerror.Visible = true;
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            for(int i = 0; i < numericUpDown1.Value; i++)
            {
                colori nuovo= new colori();
                flowLayoutPanel1.Controls.Add(nuovo);
            }
        }
    }
}
