﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace progettotps
{
    public partial class rigaclassifica : UserControl
    {
        public rigaclassifica(KeyValuePair<string, infozona> valore)
        {
            InitializeComponent();
            Console.WriteLine(valore.Key);
            colore.Text = Program.nomi[Convert.ToInt32(valore.Key)];
            blocchi.Text=valore.Value.blocchi.ToString();
            percentuale.Text = (valore.Value.blocchi / (Program.dimensioni * Program.dimensioni)*100).ToString()+"%";
            colore.ForeColor = ColorTranslator.FromHtml( Program.colori[Convert.ToInt32(valore.Key)]);
            blocchi.ForeColor = ColorTranslator.FromHtml(Program.colori[Convert.ToInt32(valore.Key)]);
            percentuale.ForeColor = ColorTranslator.FromHtml(Program.colori[Convert.ToInt32(valore.Key)]);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
