﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Globalization;
using System.Data.SqlClient;

namespace progettotps
{
    public partial class Form1 : Form
    {
        Griglia g;
        zona[] p = new zona[0];
        bool[] b = new bool[1];
        Thread[] t = new Thread[0];
        int num;
        Thread percentuale;
        public Form1(int numero,int blocchi)
        {
            num = numero;
            InitializeComponent();
            Program.f1 = this;
            Program.dimensioni = blocchi;

            dataGridView1.RowCount =blocchi;
            dataGridView1.ColumnCount = blocchi;
            int dim = Convert.ToInt32(455 / blocchi/1.4);
            /*if(dim>10)
                dim = 10;*/
            g= new Griglia();
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                row.Height = dim;
            }

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                
                column.Width = dim;
            }
            
            Dictionary<string, infozona> dic = new Dictionary<string, infozona>();
            for(int i = 0; i < numero; i++)
            {
                dic.Add((i+1).ToString(), new infozona());
            }
            classificaadd(dic);




           
            b[0] = true;
            
            p = new zona[numero];
            for (int i = 0; i < numero; i++) {
                p[i] = new zona(i + 1, ref g, ref b);
            }

            t = new Thread[numero];
            for (int i = 0; i < numero; i++)
            {
                t[i] = new Thread(new ThreadStart(p[i].prendi));
            }
            
            
            


            percentuale = new Thread(new ThreadStart(g.calcola));
            percentuale.Start();
           
            b[0] = false;


            //while (Classifica.Controls.Count != 1)
            //{
            //    Thread.Sleep(500);
            //}
            //for (int i = 0; i < numero; i++)
            //{
            //    if (t[i].IsAlive)
            //        t[i].Abort();
            //    else 
            //        t[i].Join();
            //}











        }
        public void classificaadd(Dictionary<string, infozona> dic) { 
             if (this.InvokeRequired)
    {
            this.Invoke(new MethodInvoker(() => classificaadd(dic)));
            return;
        }
             Classifica.Controls.Clear();
            
            foreach (KeyValuePair<string, infozona> a in dic.OrderByDescending(coppia => coppia.Value.blocchi))
            {
                rigaclassifica nuovo = new rigaclassifica(a);
                Classifica.Controls.Add(nuovo);
            }
        }
        public void crescendo(int numero)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(() => crescendo(numero)));
                return;
            }
            crescita.Text ="Crescendo il "+Program.nomi[numero];
            crescita.ForeColor = ColorTranslator.FromHtml(Program.colori[numero]);
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            g.mostra(ref dataGridView1);
            
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnfinish_Click(object sender, EventArgs e)
        {
            if (button1.Visible == false)
            {
                for (int i = 0; i < num; i++)
                {
                    if (t[i].IsAlive)
                        t[i].Abort();
                    else
                        t[i].Join();
                }
                percentuale.Abort();
            }
            percentuale.Abort();
            Close();
        }

        private void btn05_Click(object sender, EventArgs e)
        {
            Program.speed=0.5;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Program.speed =1;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Program.speed = 2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < num; i++)
            {
                t[i].Start();
            }
            button1.Visible = false;
        }
    }
    public class zona
    {
        int id;
        
        bool[] finito ;
        Griglia g = new Griglia();
        public zona(int id1, ref Griglia g1, ref bool[] finito1)
        {
            
            id = id1;
            
            finito =  finito1;
            g = g1;
            
            g.aggiungi(id);
            


        }
        public void prendi()
        {

            while (finito[0]) { }
            while (!finito[0])
            { 

                
                g.cresci(id);
                if (!g.esistente(id))
                {
                    
                    break;
                }
                Thread.Sleep(Convert.ToInt32(new Random().Next(500,2500)/Program.speed));
            }


        }
    }
    public class Griglia
    {
        private int[,] griglia = new int[30,30];
        Mutex mutex = new Mutex();
        bool itfine = true;
        public Griglia(){
            griglia = new int[Program.dimensioni, Program.dimensioni ];
            for (int i = 0; i < Program.dimensioni ; i++) {
                for (int j = 0; j < Program.dimensioni ; j++) {
                    griglia[i,j] = -1;
                }
            }
        }
        public void aggiungi(int numero)
        {
            bool trovato = false;
            
            while (!trovato)
            {
                int y = new Random().Next(Program.dimensioni );
                int x = new Random().Next(Program.dimensioni );
                if (griglia[x, y] == -1)
                {
                    griglia[x, y] = numero;
                    if(x<Program.dimensioni-1)
                    if (griglia[x + 1, y] == -1)
                        griglia[x + 1, y] = numero;
                    if(x>0)
                    if (griglia[x - 1, y] == -1)
                        griglia[x - 1, y] = numero;
                    if (y < Program.dimensioni - 1)
                        if (griglia[x, y + 1] == -1)
                        griglia[x, y + 1] = numero;
                    if (y > 0)
                        if (griglia[x ,y - 1] == -1)
                        griglia[x,y - 1] = numero;
                    trovato = true;
                }


            }
        }
        public bool esistente(int numero)
        {
            for (int i = 0; i < griglia.GetLength(0); i++)
            {
                for (int j = 0; j < griglia.GetLength(1); j++)
                {
                    if (griglia[i, j] == numero)
                        return true;
                }
            }
            return false;
                }
        private bool bordo(int j, int i,int numeri)
        {
            List<int> list = new List<int>();
            if (j < Program.dimensioni - 1)
            {
                list.Add(griglia[j + 1, i]);
                if (i < Program.dimensioni - 1)
                    list.Add(griglia[j + 1, i + 1]);
                else if (i > 0)
                    list.Add(griglia[j + 1, i - 1]);

            }
            if (j > 0)
            {
                list.Add(griglia[j - 1, i]);
                if(i > 0)
                    list.Add(griglia[j - 1, i - 1]);
                else if(i < Program.dimensioni - 1)
                list.Add(griglia[j - 1, i + 1]);
                
            }
            
            if(i < Program.dimensioni - 1)
                list.Add(griglia[j, i + 1]);
            else if (i > 0)
                list.Add(griglia[j, i - 1]);
            foreach(int a in list)
            {
                if (a != numeri && a != 0)
                {
                    return true;
                }
            }
            return false;

        }
        public void cresci(int numeri) {
            if (mutex.WaitOne(new TimeSpan(Convert.ToInt32(1000/Program.speed))))
            {
                itfine = false;
                Program.f1.crescendo(numeri);
                int tasso = new Random().Next(1, 5);
                for (int z = 0; z < tasso; z++)
                {
                    for (int j = 0; j < griglia.GetLength(0); j++)
                    {
                        for (int i = 0; i < griglia.GetLength(1); i++)
                        {

                            if (griglia[j, i] == numeri)
                            {
                                if (bordo(j, i, numeri))
                                {


                                    if (j < Program.dimensioni - 1)
                                    {
                                        if (griglia[j + 1, i] != numeri && griglia[j + 1, i] != 0)
                                        {

                                            griglia[j + 1, i] = 0;
                                        }
                                    }
                                    if (j > 0)
                                        if (griglia[j - 1, i] != numeri && griglia[j - 1, i] != 0)
                                        {
                                            griglia[j - 1, i] = 0;
                                        }
                                    if (i < Program.dimensioni - 1)
                                        if (griglia[j, i + 1] != numeri && griglia[j, i + 1] != 0)
                                        {
                                            griglia[j, i + 1] = 0;
                                        }
                                    if (i > 0)
                                        if (griglia[j, i - 1] != numeri && griglia[j, i - 1] != 0)
                                        {
                                            griglia[j, i - 1] = 0;
                                        }
                                    if (i < Program.dimensioni - 1 && j < Program.dimensioni - 1)
                                        if (griglia[j + 1, i + 1] != numeri && griglia[j + 1, i + 1] != 0)
                                        {
                                            griglia[j + 1, i + 1] = 0;
                                        }
                                    if (i < Program.dimensioni - 1 && j > 0)
                                        if (griglia[j - 1, i + 1] != numeri && griglia[j - 1, i + 1] != 0)
                                        {
                                            griglia[j - 1, i + 1] = 0;
                                        }
                                    if (i > 0 && j < Program.dimensioni - 1)
                                        if (griglia[j + 1, i - 1] != numeri && griglia[j + 1, i - 1] != 0)
                                        {
                                            griglia[j + 1, i - 1] = 0;
                                        }
                                    if (i > 0 && j > 0)
                                        if (griglia[j - 1, i - 1] != numeri && griglia[j - 1, i - 1] != 0)
                                        {
                                            griglia[j - 1, i - 1] = 0;
                                        }

                                }
                            }
                        }

                    }

                    for (int j = 0; j < griglia.GetLength(0); j++)
                    {
                        for (int i = 0; i < griglia.GetLength(1); i++)
                        {
                            if (griglia[j, i] == 0)
                                griglia[j, i] = numeri;
                        }
                    }
                    itfine = true;
                    
                }
                Thread.Sleep(Convert.ToInt32(new Random().Next(500, 2500)/Program.speed));
                mutex.ReleaseMutex();
            }
            
        }
        public void calcola()
        {
            
            while (true)
            {
                while (!itfine) { }
                Dictionary<string, infozona> dic = new Dictionary<string, infozona>();
                for (int j = 0; j < griglia.GetLength(0); j++)
                {
                    for (int i = 0; i < griglia.GetLength(1); i++)
                    {if (griglia[j, i] != 0 && griglia[j, i] != -1)
                            if (dic.ContainsKey(griglia[j, i].ToString()))
                            {
                                dic[griglia[j, i].ToString()].blocchi++;
                            }
                            else {
                                infozona temp = new infozona();
                                temp.blocchi = 1;
                                dic.Add(griglia[j,i].ToString(),temp );
                            }
                    }
                }
                
                
                
                    
                    Program.f1.classificaadd(dic);
                Thread.Sleep(Convert.ToInt32(2000 / Program.speed));


                
            }
        }
        public void mostra(ref DataGridView schermo)
        {
            for (int i = 0; i < griglia.GetLength(0); i++)
            {
                for (int j = 0; j < griglia.GetLength(1); j++)
                {
                    Console.WriteLine(i+ j);
                    if(griglia[i, j] != -1) 
                    schermo[j, i].Style.BackColor = ColorTranslator.FromHtml(Program.colori[griglia[i, j]]) ;
                }
            }

        }
    }
    public class infozona
    {
        private int _blocchi { get; set; }
        private string _nome { get; set; }

        public int blocchi { get { return _blocchi; } set { _blocchi = value; } }
            public string nome { get { return _nome; } set {_nome = value; } }
        public infozona() {
            _blocchi = 0;
            _nome = "";
        }
    }
}

