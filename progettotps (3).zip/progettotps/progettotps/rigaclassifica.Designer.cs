﻿namespace progettotps
{
    partial class rigaclassifica
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.colore = new System.Windows.Forms.Label();
            this.blocchi = new System.Windows.Forms.Label();
            this.percentuale = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // colore
            // 
            this.colore.AutoSize = true;
            this.colore.Location = new System.Drawing.Point(22, 44);
            this.colore.Name = "colore";
            this.colore.Size = new System.Drawing.Size(44, 16);
            this.colore.TabIndex = 0;
            this.colore.Text = "label1";
            this.colore.Click += new System.EventHandler(this.label1_Click);
            // 
            // blocchi
            // 
            this.blocchi.AutoSize = true;
            this.blocchi.Location = new System.Drawing.Point(124, 44);
            this.blocchi.Name = "blocchi";
            this.blocchi.Size = new System.Drawing.Size(44, 16);
            this.blocchi.TabIndex = 1;
            this.blocchi.Text = "label1";
            // 
            // percentuale
            // 
            this.percentuale.AutoSize = true;
            this.percentuale.Location = new System.Drawing.Point(224, 44);
            this.percentuale.Name = "percentuale";
            this.percentuale.Size = new System.Drawing.Size(44, 16);
            this.percentuale.TabIndex = 2;
            this.percentuale.Text = "label2";
            // 
            // rigaclassifica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.percentuale);
            this.Controls.Add(this.blocchi);
            this.Controls.Add(this.colore);
            this.Name = "rigaclassifica";
            this.Size = new System.Drawing.Size(455, 100);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label colore;
        private System.Windows.Forms.Label blocchi;
        private System.Windows.Forms.Label percentuale;
    }
}
