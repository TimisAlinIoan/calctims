﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace progettotps
{
    internal static class Program
    {
        public static Form1 f1;
        public static List<string> colori = new List<string>();
        public static List<string> nomi=new List<string>();
        public static double speed = 1;
        public static int dimensioni = 0;
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form2());
        }
    }
}
