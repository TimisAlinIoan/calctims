﻿namespace WinFormsApp3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblDisplay = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button0 = new Button();
            btndivisione = new Button();
            btnper = new Button();
            btnmeno = new Button();
            btnpiu = new Button();
            btnuguale = new Button();
            btnpunto = new Button();
            btnsegno = new Button();
            btnc = new Button();
            btnac = new Button();
            SuspendLayout();
            // 
            // lblDisplay
            // 
            lblDisplay.BorderStyle = BorderStyle.FixedSingle;
            lblDisplay.Font = new Font("Rubik", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDisplay.Location = new Point(116, 34);
            lblDisplay.Name = "lblDisplay";
            lblDisplay.Size = new Size(236, 40);
            lblDisplay.TabIndex = 0;
            lblDisplay.Text = "0";
            lblDisplay.TextAlign = ContentAlignment.MiddleRight;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(116, 220);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(55, 40);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(176, 220);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(55, 40);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button1_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(236, 220);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(55, 40);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button1_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.Location = new Point(116, 173);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(55, 40);
            button4.TabIndex = 4;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button1_Click;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.Location = new Point(176, 173);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(55, 40);
            button5.TabIndex = 5;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button1_Click;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.Location = new Point(236, 173);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(55, 40);
            button6.TabIndex = 6;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button1_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(116, 129);
            button7.Margin = new Padding(3, 2, 3, 2);
            button7.Name = "button7";
            button7.Size = new Size(55, 40);
            button7.TabIndex = 7;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button1_Click;
            // 
            // button8
            // 
            button8.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button8.Location = new Point(176, 129);
            button8.Margin = new Padding(3, 2, 3, 2);
            button8.Name = "button8";
            button8.Size = new Size(55, 40);
            button8.TabIndex = 8;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button1_Click;
            // 
            // button9
            // 
            button9.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button9.Location = new Point(236, 129);
            button9.Margin = new Padding(3, 2, 3, 2);
            button9.Name = "button9";
            button9.Size = new Size(55, 40);
            button9.TabIndex = 9;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button1_Click;
            // 
            // button0
            // 
            button0.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button0.Location = new Point(176, 264);
            button0.Margin = new Padding(3, 2, 3, 2);
            button0.Name = "button0";
            button0.Size = new Size(55, 40);
            button0.TabIndex = 10;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = true;
            button0.Click += button1_Click;
            // 
            // btndivisione
            // 
            btndivisione.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btndivisione.Location = new Point(297, 85);
            btndivisione.Margin = new Padding(3, 2, 3, 2);
            btndivisione.Name = "btndivisione";
            btndivisione.Size = new Size(55, 40);
            btndivisione.TabIndex = 11;
            btndivisione.Text = "/";
            btndivisione.UseVisualStyleBackColor = true;
            btndivisione.Click += btndivisione_Click;
            // 
            // btnper
            // 
            btnper.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnper.Location = new Point(297, 129);
            btnper.Margin = new Padding(3, 2, 3, 2);
            btnper.Name = "btnper";
            btnper.Size = new Size(55, 40);
            btnper.TabIndex = 12;
            btnper.Text = "*";
            btnper.UseVisualStyleBackColor = true;
            btnper.Click += btndivisione_Click;
            // 
            // btnmeno
            // 
            btnmeno.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnmeno.Location = new Point(297, 173);
            btnmeno.Margin = new Padding(3, 2, 3, 2);
            btnmeno.Name = "btnmeno";
            btnmeno.Size = new Size(55, 40);
            btnmeno.TabIndex = 13;
            btnmeno.Text = "-";
            btnmeno.UseVisualStyleBackColor = true;
            btnmeno.Click += btndivisione_Click;
            // 
            // btnpiu
            // 
            btnpiu.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnpiu.Location = new Point(297, 220);
            btnpiu.Margin = new Padding(3, 2, 3, 2);
            btnpiu.Name = "btnpiu";
            btnpiu.Size = new Size(55, 40);
            btnpiu.TabIndex = 14;
            btnpiu.Text = "+";
            btnpiu.UseVisualStyleBackColor = true;
            btnpiu.Click += btndivisione_Click;
            // 
            // btnuguale
            // 
            btnuguale.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnuguale.Location = new Point(297, 264);
            btnuguale.Margin = new Padding(3, 2, 3, 2);
            btnuguale.Name = "btnuguale";
            btnuguale.Size = new Size(55, 40);
            btnuguale.TabIndex = 15;
            btnuguale.Text = "=";
            btnuguale.UseVisualStyleBackColor = true;
            btnuguale.Click += btnuguale_Click;
            // 
            // btnpunto
            // 
            btnpunto.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnpunto.Location = new Point(237, 264);
            btnpunto.Margin = new Padding(3, 2, 3, 2);
            btnpunto.Name = "btnpunto";
            btnpunto.Size = new Size(55, 40);
            btnpunto.TabIndex = 16;
            btnpunto.Text = ",";
            btnpunto.UseVisualStyleBackColor = true;
            btnpunto.Click += button1_Click;
            // 
            // btnsegno
            // 
            btnsegno.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnsegno.Location = new Point(116, 264);
            btnsegno.Margin = new Padding(3, 2, 3, 2);
            btnsegno.Name = "btnsegno";
            btnsegno.Size = new Size(55, 40);
            btnsegno.TabIndex = 17;
            btnsegno.Text = "+/-";
            btnsegno.UseVisualStyleBackColor = true;
            btnsegno.Click += btnsegno_Click;
            // 
            // btnc
            // 
            btnc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnc.Location = new Point(237, 85);
            btnc.Margin = new Padding(3, 2, 3, 2);
            btnc.Name = "btnc";
            btnc.Size = new Size(55, 40);
            btnc.TabIndex = 18;
            btnc.Text = "C";
            btnc.UseVisualStyleBackColor = true;
            btnc.Click += btnc_Click;
            // 
            // btnac
            // 
            btnac.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnac.Location = new Point(176, 85);
            btnac.Margin = new Padding(3, 2, 3, 2);
            btnac.Name = "btnac";
            btnac.Size = new Size(55, 40);
            btnac.TabIndex = 19;
            btnac.Text = "AC";
            btnac.UseVisualStyleBackColor = true;
            btnac.Click += btnac_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(452, 338);
            Controls.Add(btnac);
            Controls.Add(btnc);
            Controls.Add(btnsegno);
            Controls.Add(btnpunto);
            Controls.Add(btnuguale);
            Controls.Add(btnpiu);
            Controls.Add(btnmeno);
            Controls.Add(btnper);
            Controls.Add(btndivisione);
            Controls.Add(button0);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblDisplay);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Label lblDisplay;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button0;
        private Button btndivisione;
        private Button btnper;
        private Button btnmeno;
        private Button btnpiu;
        private Button btnuguale;
        private Button btnpunto;
        private Button btnsegno;
        private Button btnc;
        private Button btnac;
    }
}
