﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gallery
{
    public partial class Form1 : Form
    {
        string[] immagini;
        int imm = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btncarica_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imm = 0;

                label1.Text = "galleria in esecuzione";
                immagini = openFileDialog1.FileNames.ToArray();
                timer1.Enabled = true;
                pictureBox1.Image = Image.FromFile(immagini[0]);
                imm++;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
                pictureBox1.Image = Image.FromFile(immagini[imm]);
                imm++;

            if (imm == immagini.Length)
            {
                timer1.Enabled = false;
                label1.Text = "finito";
            }
        }

       

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if(numericUpDown1.Value>100)
            timer1.Interval =Convert.ToInt32( numericUpDown1.Value);
            else
                timer1.Interval = 1000;
        }
    }
}
