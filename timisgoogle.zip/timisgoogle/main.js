const express = require('express');
const path = require('path');
const app = express();
const fs = require('fs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));
file=fs.readFileSync("cronologia.json","utf8")
cronologia=JSON.parse(file);
file1=fs.readFileSync("preferiti.json","utf8")
preferiti=JSON.parse(file1);

app.get("/",(req,res)=>{
    html="<html><head> <link rel=\"stylesheet\" href=\"style.css\"></head><body><div style=\"display: block; font-size: 100px; width: 100%; text-align:center; align-items:center;margin:10% 0 0 0\">TIMIS GOOGLE</div><div style=\"display: block; font-size: 20px; width: 100%; text-align:center; align-items:center\">" ;
    ricerca="<form action=\"/\" method=\"post\"><input type=\"text\" style=\"width:50%;height:40px\" name=\"ricerca\"><button style=\"height:40px\" type=\"submit\">Cerca</button></form>"
    html+=ricerca;
    prefe="<h4>preferiti</h4><div style=\"display:inline-flex;flex-wrap:wrap;width: auto;max-width: 40%; border:black;border-style: solid;margin: 0 auto; \" >"
    preferiti.forEach(e=>{
        elimina="<form action=\"/elimina\" method=\"post\"><input type=\"text\" name=\"togli\" value=\""+e.link+"\" style=\"display:none;\" ><button type=\"submit\">elimina</button></form>"
        prefe+="<div style=\"display: flex;flex-direction: column;width:100px;height:100px;border:black;border-style: solid;justify-content:center; \"><a   href=\""+e.link+"\">"+e.nome+"</a>"+elimina+"</div>";
        
        
    })
    prefe+="</div>"
    html+=prefe;
    aggiungi="<form action=\"/aggiungi\" method=\"get\"><button type=\"submit\">Aggiungi</button></form>"
    html+=aggiungi;
    crono="<form action=\"/cronologia\" method=\"get\"><button style=\"position:absolute;right:40px;\" type=\"submit\">crononologia</button></form>"
    html+=crono;
    html+="</div></body></html>"
    res.send(html)
})
app.post("/",(req,res)=>{
    oggetto={}
    temp=req.body.ricerca.split("&")
    if(temp.count==1){
    oggetto.ricerca=req.body.ricerca;
    cronologia.push(oggetto)
    file=JSON.stringify(cronologia)
    fs.writeFileSync("cronologia.json",file,"utf8")
    }
    fetch("https://www.googleapis.com/customsearch/v1?key=AIzaSyAwzXrg6JHkpyw_Hc4dyCjmwcub3MKmDFs&cx=b6cf6faa97dd04e7d&q="+req.body.ricerca)
    .then(e=>e.json())
    .then(e=>{
            html="<html><head> <link rel=\"stylesheet\" href=\"style.css\"></head><body><div style=\"display: block; font-size: 70px; width: 100%; text-align:center; align-items:center\">TIMIS GOOGLE</div>"
            ricerca="<form action=\"/\" method=\"post\"><input type=\"text\" style=\"width:20%\" name=\"ricerca\"><button type=\"submit\">Cerca</button></form>"
            torna="<form action=\"/\" method=\"get\"><button type=\"submit\">torna</button></form>"
            html+=ricerca;
            html+=torna;
            e.items.forEach(elemento => {
                if(elemento!=undefined){
                img=""
                console.log(elemento)
                if(elemento.pagemap.cse_thumbnail!=undefined)
                img="<img src=\""+elemento.pagemap.cse_thumbnail[0].src+"\" width=\"100\" height=\"100\">"
                
                dato="<div style=\"display:flex; flex-wrap:wrap;\">"+img+ "<div><a style=\"font-size: 30px\" href=\""+elemento.link+"\">"+elemento.title+"</a><br><a style=\"font-size: 10px\" href=\""+elemento.link+"\">"+elemento.snippet+"</a><br><a style=\"font-size: 20px\" href=\""+elemento.link+"\">"+elemento.displayLink+"</a><br></div></div><br><br>"
                

                html+=dato;
            }
            });
            
            if(e.queries.nextPage!=undefined){
                paginasuccessiva="<form action=\"/\" method=\"post\"><input type=\"text\" style=\"width:20%;display:none;\" name=\"ricerca\"  value=\""+e.queries.nextPage[0].searchTerms+"&num="+e.queries.nextPage[0].count+"&start="+e.queries.nextPage[0].startIndex+"\"><button type=\"submit\">successivo</button></form>"
                html+=paginasuccessiva;
            }
            if(e.queries.previousPage!=undefined){
                paginaprima="<form action=\"/\" method=\"post\"><input type=\"text\" style=\"width:20%;display:none;\" name=\"ricerca\"  value=\""+e.queries.previousPage[0].searchTerms+"&num="+e.queries.previousPage[0].count+"&start="+e.queries.previousPage[0].startIndex+"\"><button type=\"submit\">precedente</button></form>"
                html+=paginaprima;
            }

            html+="</body></html>";
            res.send(html)

        
    })
    .catch(e=>{res.send("errore nella ricerca")
        console.error(e)
        
    })
})
app.get("/aggiungi",(req,res)=>{
    html="<html><head> <link rel=\"stylesheet\" href=\"style.css\"></head><body style=\"text-align:center; align-items:center\"><div style=\"display: block; font-size: 70px; width: 100%; text-align:center; align-items:center\">Aggiungi preferiti</div>"
    html+="<form action=\"/aggiungi\" method=\"post\">nome: <input type=\"text\" name=\"nome\" required><br>link: <input type=\"text\" name=\"link\" required><br><input type=\"submit\" value=\"invia\"></form>"
    torna="<form action=\"/\" method=\"get\"><button type=\"submit\">torna</button></form>"
    html+=torna;
    html+="</div></body></html>"
    res.send(html)

})
app.post("/aggiungi",(req,res)=>{
    if(req.body.link!=undefined){
    oggetto={}
    oggetto.link=req.body.link
    oggetto.nome=req.body.nome
    preferiti.push(oggetto)
    file1=JSON.stringify(preferiti)
    fs.writeFileSync("preferiti.json",file1,"utf8")
    res.redirect("/")
    }
})
app.post("/elimina",(req,res)=>{
    preferiti=preferiti.filter(e=>e.link!=req.body.togli)
    res.redirect("/")
})
app.get("/cronologia",(req,res)=>{
    html="<html><head> <link rel=\"stylesheet\" href=\"style.css\"></head><body style=\"text-align:center; align-items:center\"><div style=\"display: block; font-size: 70px; width: 100%; text-align:center; align-items:center\">Cronologia</div>"
    torna="<form action=\"/\" method=\"get\"><button type=\"submit\">torna</button></form>"
    html+=torna
    prefe="<div style=\"display:flex;flex-wrap:wrap;width:30%; margin: 0 auto; \" >"
    cronologia.forEach(e=>{
        
        prefe+="<div style=\"display: flex;flex-direction: column;width:1000%;height:50px;justify-content:center; \"><form action=\"/\" method=\"post\"><input type=\"text\" style=\" display:none;width:50%;height:40px\" value=\""+e.ricerca+"\" name=\"ricerca\"><button style=\"height:100%;width:100%\" type=\"submit\">"+e.ricerca+"</button></form></div>";
        
        
    })
    prefe+="</div>"
    html+=prefe;
    res.send(html)

})
app.listen(3000, () => {
    console.log('http://localhost:3000');
});